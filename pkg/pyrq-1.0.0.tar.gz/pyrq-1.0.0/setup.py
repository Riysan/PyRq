import setuptools
 
setuptools.setup(
    name="pyrq",
    version="1.0.0",
    author="riysan",
    install_requires = ["requests"],
    url="https://github.com/Riysan/PyRq/",
    packages=setuptools.find_packages(),
    license = "MIT"
)
